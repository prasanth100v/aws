#!/bin/bash
set -euo pipefail

# ── Bootstrap script for ${project_name} (${environment}) ──────────────────

echo "==> Updating system packages"
dnf update -y

echo "==> Installing common utilities"
dnf install -y \
  amazon-cloudwatch-agent \
  aws-cli \
  curl \
  git \
  htop \
  jq \
  unzip \
  wget

echo "==> Configuring CloudWatch Agent"
cat > /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json <<'EOF'
{
  "metrics": {
    "namespace": "CWAgent",
    "metrics_collected": {
      "mem": {
        "measurement": ["mem_used_percent"],
        "metrics_collection_interval": 60
      },
      "disk": {
        "measurement": ["used_percent"],
        "resources": ["/"],
        "metrics_collection_interval": 60
      },
      "cpu": {
        "totalcpu": true,
        "metrics_collection_interval": 60
      }
    }
  },
  "logs": {
    "logs_collected": {
      "files": {
        "collect_list": [
          {
            "file_path": "/var/log/messages",
            "log_group_name": "/ec2/${project_name}-${environment}",
            "log_stream_name": "{instance_id}/system",
            "retention_in_days": 30
          }
        ]
      }
    }
  }
}
EOF

systemctl enable amazon-cloudwatch-agent
systemctl start amazon-cloudwatch-agent

echo "==> Setting up hostname"
hostnamectl set-hostname "${project_name}-${environment}"

echo "==> Bootstrap complete"
