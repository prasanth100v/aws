################################################################################
# Outputs
################################################################################

output "instance_id" {
  description = "EC2 instance ID"
  value       = aws_instance.main.id
}

output "instance_arn" {
  description = "EC2 instance ARN"
  value       = aws_instance.main.arn
}

output "instance_state" {
  description = "Current state of the EC2 instance"
  value       = aws_instance.main.instance_state
}

output "public_ip" {
  description = "Public IP address of the EC2 instance"
  value       = var.assign_elastic_ip ? aws_eip.ec2[0].public_ip : aws_instance.main.public_ip
}

output "private_ip" {
  description = "Private IP address of the EC2 instance"
  value       = aws_instance.main.private_ip
}

output "public_dns" {
  description = "Public DNS name of the EC2 instance"
  value       = aws_instance.main.public_dns
}

output "ami_id" {
  description = "AMI ID used for the instance"
  value       = aws_instance.main.ami
}

output "vpc_id" {
  description = "ID of the created VPC"
  value       = aws_vpc.main.id
}

output "public_subnet_ids" {
  description = "IDs of the public subnets"
  value       = aws_subnet.public[*].id
}

output "security_group_id" {
  description = "ID of the EC2 security group"
  value       = aws_security_group.ec2.id
}

output "iam_role_arn" {
  description = "ARN of the EC2 IAM role"
  value       = aws_iam_role.ec2.arn
}

output "ssh_command" {
  description = "SSH command to connect (only if key pair is configured)"
  value       = var.public_key_path != "" ? "ssh -i <your-private-key> ec2-user@${var.assign_elastic_ip ? aws_eip.ec2[0].public_ip : aws_instance.main.public_ip}" : "No key pair configured. Use SSM Session Manager instead."
}

output "ssm_connect_command" {
  description = "AWS CLI command to connect via SSM Session Manager"
  value       = "aws ssm start-session --target ${aws_instance.main.id} --region ${var.aws_region}"
}
