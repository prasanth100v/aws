################################################################################
# Variables
################################################################################

variable "aws_region" {
  description = "AWS region to deploy resources"
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Name of the project (used for resource naming)"
  type        = string
  default     = "myapp"
}

variable "environment" {
  description = "Deployment environment (dev, staging, prod)"
  type        = string
  default     = "dev"

  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "Environment must be one of: dev, staging, prod."
  }
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "az_count" {
  description = "Number of availability zones / public subnets to create"
  type        = number
  default     = 2
}

variable "instance_type" {
  description = "EC2 instance type"
  type        = string
  default     = "t3.micro"
}

variable "ami_id" {
  description = "Custom AMI ID. Leave empty to use the latest Amazon Linux 2023."
  type        = string
  default     = ""
}

variable "root_volume_size" {
  description = "Size of the root EBS volume in GB"
  type        = number
  default     = 20
}

variable "public_key_path" {
  description = "Path to SSH public key file. Leave empty to skip key pair creation."
  type        = string
  default     = ""
}

variable "assign_elastic_ip" {
  description = "Whether to assign an Elastic IP to the instance"
  type        = bool
  default     = false
}

variable "enable_detailed_monitoring" {
  description = "Enable detailed (1-minute) CloudWatch monitoring"
  type        = bool
  default     = false
}

variable "cpu_alarm_threshold" {
  description = "CPU utilization percentage threshold for CloudWatch alarm"
  type        = number
  default     = 80
}

variable "allowed_ingress_ports" {
  description = "List of ingress port rules for the EC2 security group"
  type = list(object({
    port        = number
    description = string
    cidr_blocks = list(string)
  }))
  default = [
    {
      port        = 22
      description = "SSH access"
      cidr_blocks = ["0.0.0.0/0"]  # Restrict this to your IP in production!
    },
    {
      port        = 80
      description = "HTTP traffic"
      cidr_blocks = ["0.0.0.0/0"]
    },
    {
      port        = 443
      description = "HTTPS traffic"
      cidr_blocks = ["0.0.0.0/0"]
    }
  ]
}
